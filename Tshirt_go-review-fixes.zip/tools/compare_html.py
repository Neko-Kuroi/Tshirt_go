"""Flask 版と Go 版の画面 (HTML) を、同じ DB で描画して、構造ごと比較する。

  GO_HTML_OUT=/tmp/go_pages go test ./internal/web -run WritePages     # Go 側の出力
  python tools/compare_html.py <Flask版の inventory_app> /tmp/go_pages  # Flask 側を描画して比較

意味のない差 (空白、属性の並び、class の並び、空の class、CSRF トークンの値、真偽属性の書き方) は無視して、
タグ・属性・文字の並びを比べる。差があれば、先頭の差を前後の文脈つきで出す。
"""
import json
import pathlib
import re
import shutil
import sys
import tempfile
from html.parser import HTMLParser

app_dir = pathlib.Path(sys.argv[1]).resolve()
go_dir = pathlib.Path(sys.argv[2]).resolve()
sys.path.insert(0, str(app_dir))
golden = pathlib.Path(__file__).resolve().parent.parent / "internal/service/testdata/golden/inventory.db"

from app import create_app  # noqa: E402
from config import Config  # noqa: E402

tmp = pathlib.Path(tempfile.mkdtemp())
shutil.copy(golden, tmp / "inventory.db")


class Cfg(Config):
    DATABASE = str(tmp / "inventory.db")


app = create_app(Cfg)


class Canon(HTMLParser):
    """HTML を、(種類, 内容) の列にする。"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        d = {}
        for k, v in attrs:
            v = "" if v is None else v
            if k == "class":
                v = " ".join(sorted(v.split()))
                if not v:
                    continue  # class="" は無いのと同じ
            if k == "value" and d.get("name") == "csrf_token":
                v = "<csrf>"
            d[k] = v
        # name が value より後に来る場合に備えて、csrf_token の value は最後に置き換える
        if d.get("name") == "csrf_token" and "value" in d:
            d["value"] = "<csrf>"
        if tag in ("script", "style"):
            self.skip += 1
        self.out.append(("<" + tag, tuple(sorted(d.items()))))

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.skip:
            self.skip -= 1
        self.out.append(("</" + tag, ()))

    def handle_data(self, data):
        t = re.sub(r"\s+", " ", data).strip()
        if t and not self.skip:
            self.out.append(("text", t))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)


VOID = {"meta", "link", "input", "br", "hr", "img", "option_"}


def canon(html):
    c = Canon()
    c.feed(html)
    c.close()
    # void 要素は、終了タグを書く書かない (<br> と <br/>) の違いを無視する
    return [t for t in c.out if not (t[0].startswith("</") and t[0][2:] in VOID)]


def login(user):
    c = app.test_client()
    html = c.get("/login").get_data(as_text=True)
    tok = re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
    r = c.post("/login", data={"username": user, "password": "password123", "csrf_token": tok})
    assert r.status_code == 302, r.status_code
    return c


clients = {"admin": login("admin"), "staff": login("staff")}
index = json.loads((go_dir / "index.json").read_text(encoding="utf-8"))
bad = 0
status_bad = 0
for key, entry in index.items():
    who, path = key.split(" ", 1)
    fname, go_status = (entry["file"], entry["status"]) if isinstance(entry, dict) else (entry, 200)
    resp = clients[who].get(path)
    if resp.status_code != go_status:  # ステータス (200 / 403 / 404 ...) も一致すること。ログイン画面への 302 は不可
        status_bad += 1
        print(f"STATUS {key}: Flask {resp.status_code}, Go {go_status}")
        continue
    flask_html = resp.get_data(as_text=True)
    go_html = (go_dir / fname).read_text(encoding="utf-8")
    a, b = canon(flask_html), canon(go_html)
    if a == b:
        continue
    bad += 1
    i = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
    print(f"\nDIFF {key}  (Flask {len(a)} tokens, Go {len(b)} tokens, first difference at {i})")
    for label, seq in (("Flask", a), ("Go   ", b)):
        print(f"  {label}: " + " | ".join(f"{t[0]}{t[1] if t[1] else ''}" for t in seq[max(0, i - 2): i + 3])[:400])
    if bad >= 8:
        print("... (最初の8件だけ表示)")
        break
sizes = [len(canon((go_dir / (e["file"] if isinstance(e, dict) else e)).read_text(encoding="utf-8"))) for e in index.values()]
print(f"\n{len(index)} pages compared, {bad} differ, {status_bad} status mismatches (tokens per page: min {min(sizes)}, max {max(sizes)})")
sys.exit(1 if bad or status_bad else 0)
