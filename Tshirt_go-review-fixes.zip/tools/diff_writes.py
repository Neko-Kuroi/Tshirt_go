"""書き込み系の差分テスト: 同じ操作列を Flask 版と Go 版に送り、応答と最終的な DB を比べる。

  python tools/diff_writes.py <Flask版の inventory_app> <inventory のバイナリ>

検証用 DB (internal/service/testdata/golden/inventory.db) を2つにコピーし、同じ POST を同じ順に送る。
比べるもの: ステータス、リダイレクト先、画面に出るメッセージ (flash / エラー本文)、
最終的な DB (id・外部キー・数量・履歴の種類と増減・備考など。時刻・UUID・ハッシュは除く)、パスワード変更後のログイン可否。
"""
import html
import http.cookiejar
import json
import os
import pathlib
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

app_dir, binary = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2]
sys.path.insert(0, str(app_dir))
root = pathlib.Path(__file__).resolve().parent.parent
golden_db = root / "internal/service/testdata/golden/inventory.db"
tmp = pathlib.Path(tempfile.mkdtemp())
flask_db, go_db = tmp / "flask.db", tmp / "go.db"
shutil.copy(golden_db, flask_db)
shutil.copy(golden_db, go_db)

from app import create_app  # noqa: E402
from config import Config  # noqa: E402


class Cfg(Config):
    DATABASE = str(flask_db)


flask_app = create_app(Cfg)
import atexit
import socket

with socket.socket() as _s:  # 空いているポートを選ぶ (前の実行のサーバーが残っていても、取り違えない)
    _s.bind(("127.0.0.1", 0))
    PORT = _s.getsockname()[1]
env = dict(os.environ, INVENTORY_DATABASE=str(go_db), INVENTORY_SECRET_KEY="y" * 32)
go_proc = subprocess.Popen([binary, "serve", "--addr", f"127.0.0.1:{PORT}"], env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
atexit.register(lambda: go_proc.poll() is None and go_proc.kill())  # 異常終了でも、サーバーを残さない
BASE = f"http://127.0.0.1:{PORT}"
for _ in range(60):
    try:
        urllib.request.urlopen(BASE + "/static/app.css", timeout=1)
        break
    except Exception:
        time.sleep(0.1)
else:
    go_proc.kill()
    sys.exit("Go server did not start")


# ---- 2つの実装を、同じ形で扱う ------------------------------------------------------------

class FlaskDriver:
    def __init__(self):
        self.c = flask_app.test_client()

    def get(self, path):
        r = self.c.get(path)
        return r.status_code, r.headers.get("Location", ""), r.get_data(as_text=True)

    def post(self, path, data):
        r = self.c.post(path, data=data)
        return r.status_code, r.headers.get("Location", ""), r.get_data(as_text=True)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class GoDriver:
    def __init__(self):
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()), NoRedirect())

    def _do(self, req):
        try:
            with self.op.open(req, timeout=30) as r:
                return r.status, r.headers.get("Location", ""), r.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            return e.code, e.headers.get("Location", ""), e.read().decode("utf-8", errors="replace")

    def get(self, path):
        return self._do(urllib.request.Request(BASE + path))

    def post(self, path, data):
        return self._do(urllib.request.Request(BASE + path, data=urllib.parse.urlencode(data).encode()))


ALERT = re.compile(r'<div class="alert alert-(\w+)[^"]*" role="alert">\s*(.*?)\s*</div>', re.S)
PTAG = re.compile(r"<p>(.*?)</p>", re.S)
CSRF = re.compile(r'name="csrf_token" value="([^"]+)"')


def squash(s):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", s))).strip()


class Session:
    def __init__(self, driver):
        self.d = driver

    def token(self, page):
        st, _, body = self.d.get(page)
        m = CSRF.search(body)
        assert m, f"no csrf token on {page} ({st})"
        return m.group(1)

    def summarize(self, st, loc, body):
        out = {"status": st, "location": loc}
        if st < 300 or st >= 400:
            out["flashes"] = [(k, squash(v)) for k, v in ALERT.findall(body)]
            if st >= 400:
                out["error_text"] = [squash(p) for p in PTAG.findall(body)]
        return out

    def post(self, path, data, token_page="/account/password", csrf=True):
        data = dict(data)
        if csrf:
            data["csrf_token"] = self.token(token_page)
        st, loc, body = self.d.post(path, data)
        res = self.summarize(st, loc, body)
        if 300 <= st < 400 and loc.startswith("/"):  # リダイレクト先を開いて、flash を読む
            st2, loc2, body2 = self.d.get(loc)
            res["after"] = self.summarize(st2, loc2, body2)
        return res

    def get(self, path):
        return self.summarize(*self.d.get(path))


def login(sess, user, pw):
    return sess.post("/login", {"username": user, "password": pw}, token_page="/login")


def new_session(make, user=None, pw="password123"):
    s = Session(make())
    if user:
        r = login(s, user, pw)
        assert r["status"] == 302, (user, r)
    return s


# ---- 操作列 ------------------------------------------------------------------------------

raw = sqlite3.connect(golden_db)


def vid(item, color, size="", vn=""):
    r = raw.execute("SELECT id FROM variant WHERE item_id=? AND color=? AND size=? AND variant_name=?",
                    (item, color, size, vn)).fetchone()
    assert r, (item, color, size, vn)
    return r[0]


products = [r[0] for r in raw.execute("SELECT id FROM printed_product ORDER BY id")]
BIG = "9" * 40
steps = []  # (who, method, path, data, 説明)


def S(who, path, data=None, method="POST", desc=""):
    steps.append((who, method, path, data or {}, desc or path))


# 認証
S("anon", "/login", {"username": "admin", "password": "wrong"}, desc="login wrong password")
S("anon", "/login", {"username": "nobody", "password": "x"}, desc="login unknown user")
S("anon", "/receive", {"item_id": "1"}, desc="anonymous POST to protected page")
S("staff", "/logout", {}, desc="logout then relogin handled below")

# 入荷
V1 = vid(1, "黒", "M")
rec = lambda **kw: dict({"item_id": "1", "color": "黒", "size": "M", "variant_name": "", "qty": "5", "note": ""}, **kw)
S("staff", "/receive", rec(note="n1"), desc="receive ok")
S("staff", "/receive", rec(item_id="2", color="赤", size="M", qty="1000000"), desc="receive at limit (別の在庫。V1 を巨大にすると、あとの在庫超過の試験ができなくなる)")
S("staff", "/receive", rec(qty="1000001"), desc="receive over limit")
for q in ["0", "-5", "abc", "", "１２", "1_0", " 7 ", BIG, "+3", "3.5", "１_２"]:
    S("staff", "/receive", rec(qty=q), desc=f"receive qty={q[:12]!r}")
for it in ["", "999", "abc", "13", BIG, "-1", "0", "１"]:
    S("staff", "/receive", rec(item_id=it), desc=f"receive item_id={it[:12]!r}")
S("staff", "/receive", rec(color=""), desc="receive no color")
S("staff", "/receive", rec(color="   "), desc="receive blank color")
S("staff", "/receive", rec(size=""), desc="receive no size")
S("staff", "/receive", rec(color="　赤　", size=" S "), desc="receive stripped color/size")
S("staff", "/receive", {"item_id": "3", "variant_name": "", "qty": "2"}, desc="badge without variant name")
S("staff", "/receive", {"item_id": "3", "variant_name": "青", "color": "無視", "size": "無視", "qty": "2"}, desc="badge ignores color/size")
S("staff", "/receive", {"item_id": "14", "color": "紺", "size": "無視", "qty": "4"}, desc="cap color only")
S("staff", "/receive", rec(note="　長い　メモ　"), desc="receive note spaces")
S("staff", "/receive", rec(item_id="2", color="白", size="XL"), desc="receive other item")

# プリント変換
conv = lambda **kw: dict({"variant_id": str(V1), "design": "", "design_new": "新柄", "used": "2", "output": "2", "note": ""}, **kw)
S("staff", "/convert", conv(), desc="convert ok new design")
S("staff", "/convert", conv(design_new="", design="ねこロゴ", used="1", output="0"), desc="convert zero output existing design")
S("staff", "/convert", conv(used="99999", output="1"), desc="convert more than stock")
S("staff", "/convert", conv(used="3", output="4"), desc="convert output > used")
for u, o in [("1", "-1"), ("0", "0"), ("abc", "1"), ("1", ""), ("", ""), ("２", "１"), (BIG, "1"), ("1000001", "1")]:
    S("staff", "/convert", conv(used=u, output=o), desc=f"convert used={u[:10]!r} output={o[:10]!r}")
S("staff", "/convert", conv(design_new="", design=""), desc="convert no design")
S("staff", "/convert", conv(design_new="   ", design="ねこロゴ"), desc="convert blank design_new falls back")
S("staff", "/convert", conv(design_new=" 新柄 "), desc="convert design_new stripped (existing)")
for v in ["99999", "", "abc", str(vid(3, "", "", "赤"))]:
    S("staff", "/convert", conv(variant_id=v), desc=f"convert variant_id={v!r}")
S("staff", "/convert", conv(variant_id=str(vid(13, "赤", "L"))), desc="convert stopped item")
S("staff", "/convert", conv(note="メモ"), desc="convert with note")

# 出荷・棚卸し調整
mv = lambda **kw: dict({"kind": "ship", "target": f"v:{V1}", "qty": "1", "note": ""}, **kw)
S("staff", "/move", mv(), desc="ship ok")
S("staff", "/move", mv(qty="99999"), desc="ship more than stock")
for q in ["0", "-1", "abc", "", "１"]:
    S("staff", "/move", mv(qty=q), desc=f"ship qty={q!r}")
S("staff", "/move", mv(kind="adjust", qty="5", note="棚卸し"), desc="adjust +5")
S("staff", "/move", mv(kind="adjust", qty="-3", note="棚卸し"), desc="adjust -3")
S("staff", "/move", mv(kind="adjust", qty="-99999", note="棚卸し"), desc="adjust below zero")
S("staff", "/move", mv(kind="adjust", qty="2", note=""), desc="adjust without reason")
S("staff", "/move", mv(kind="adjust", qty="2", note="　"), desc="adjust blank reason")
S("staff", "/move", mv(kind="adjust", qty="0", note="x"), desc="adjust zero")
S("staff", "/move", mv(kind="adjust", qty="1000001", note="x"), desc="adjust over limit")
S("staff", "/move", mv(kind="adjust", qty="-1000001", note="x"), desc="adjust under -limit")
S("staff", "/move", mv(kind=""), desc="no kind")
S("staff", "/move", mv(kind="bogus"), desc="bogus kind")
for t in ["", "x:1", "v:99999", "v:", "p:99999", "v:abc", ":1", "v:１", f"v:{BIG}"]:
    S("staff", "/move", mv(target=t), desc=f"target={t[:15]!r}")
S("staff", "/move", mv(target=f"p:{products[0]}", qty="1"), desc="ship printed")
S("staff", "/move", mv(target=f"p:{products[0]}", qty="99999"), desc="ship printed too many")
S("staff", "/move", mv(target=f"p:{products[0]}", kind="adjust", qty="-1", note="破れ"), desc="adjust printed")

# 備考
note = lambda **kw: dict({"item_id": "1", "target": "黒", "body": "メモ", "back": "/blank?category=1"}, **kw)
S("staff", "/notes", note(), desc="note add ok")
S("staff", "/notes", note(back="https://evil.example/"), desc="note add evil back")
S("staff", "/notes", note(back=""), desc="note add no back")
S("staff", "/notes", note(back="//evil.example"), desc="note add protocol-relative back")
S("staff", "/notes", note(body=""), desc="note empty body")
S("staff", "/notes", note(body="  　"), desc="note blank body")
S("staff", "/notes", note(body="あ" * 1000), desc="note body 1000")
S("staff", "/notes", note(body="あ" * 1001), desc="note body 1001")
S("staff", "/notes", note(target="あ" * 64), desc="note target 64")
S("staff", "/notes", note(target="あ" * 65), desc="note target 65")
S("staff", "/notes", note(target=""), desc="note no target")
S("staff", "/notes", note(target="存在しない色"), desc="note target not a color of the item")
S("staff", "/notes", note(body="1行目\n2行目"), desc="note newline")
for it in ["999", "abc", "", "13", BIG]:
    S("staff", "/notes", note(item_id=it), desc=f"note item_id={it[:10]!r}")
S("staff", "/notes/1/resolve", {"back": "/notes?"}, desc="resolve toggle on")
S("staff", "/notes/1/resolve", {"back": "/notes?"}, desc="resolve toggle off")
S("staff", "/notes/9999/resolve", {"back": "/notes?"}, desc="resolve unknown")
S("staff", "/notes/abc/resolve", {}, desc="resolve non-numeric id")
S("staff", "/notes/2/resolve", {"back": "https://evil.example"}, desc="resolve evil back")
S("staff", "/notes/2/delete", {"back": "/notes?"}, desc="staff cannot delete")
S("admin", "/notes/2/delete", {"back": "/notes?"}, desc="admin delete")
S("admin", "/notes/9999/delete", {"back": "/notes?"}, desc="admin delete unknown")

# 管理: カテゴリー
cat = lambda **kw: dict({"name": "新カテゴリー", "uses_color": "on", "uses_size": "on", "is_printable": "on"}, **kw)
S("admin", "/admin/categories", cat(), desc="category add")
S("admin", "/admin/categories", cat(), desc="category add duplicate")
S("admin", "/admin/categories", cat(name=""), desc="category add empty name")
S("admin", "/admin/categories", cat(name="　空白　"), desc="category add spaced name")
S("admin", "/admin/categories", cat(name="あ" * 100), desc="category add long name")
S("admin", "/admin/categories", {"name": "フラグなし"}, desc="category add no flags")
S("staff", "/admin/categories", cat(name="スタッフ"), desc="staff cannot add category")
cedit = lambda **kw: dict({"name": "改名", "sort_order": "7", "uses_color": "on", "uses_size": "on", "is_printable": "on"}, **kw)
S("admin", "/admin/categories/5", cedit(), desc="category edit rename")
S("admin", "/admin/categories/5", cedit(sort_order=""), desc="category edit empty order")
S("admin", "/admin/categories/5", cedit(sort_order="abc"), desc="category edit bad order")
S("admin", "/admin/categories/5", cedit(sort_order="-3"), desc="category edit negative order")
S("admin", "/admin/categories/5", cedit(sort_order=BIG), desc="category edit huge order")
S("admin", "/admin/categories/5", cedit(name="Tシャツ"), desc="category edit duplicate name")
S("admin", "/admin/categories/5", cedit(name=""), desc="category edit empty name")
S("admin", "/admin/categories/1", {"name": "Tシャツ", "sort_order": "0", "uses_color": "on"}, desc="turn off used uses_size")
S("admin", "/admin/categories/1", {"name": "Tシャツ", "sort_order": "0", "uses_size": "on"}, desc="turn off used uses_color")
S("admin", "/admin/categories/999", cedit(), desc="category edit unknown")
S("admin", "/admin/categories/abc", cedit(), desc="category edit non-numeric")
S("admin", "/admin/categories/" + BIG, cedit(), desc="category edit huge id")

# 管理: 品番
itm = lambda **kw: dict({"category_id": "1", "brand": "NewB", "item_no": "N1", "name": "新品番", "style": "半袖"}, **kw)
S("admin", "/admin/items", itm(), desc="item add")
S("admin", "/admin/items", itm(), desc="item add duplicate")
S("admin", "/admin/items", itm(brand="", item_no=""), desc="item add no brand/no")
S("admin", "/admin/items", itm(brand="", item_no="X"), desc="item add item_no only")
S("admin", "/admin/items", itm(brand="B2", item_no="", name=""), desc="item add brand only")
S("admin", "/admin/items", itm(item_no="N2", style="あ" * 31), desc="item add style 31")
S("admin", "/admin/items", itm(item_no="N3", style="あ" * 30), desc="item add style 30")
for c in ["999", "", "abc", "２", BIG]:
    S("admin", "/admin/items", itm(item_no="N9", category_id=c), desc=f"item add category_id={c[:8]!r}")
S("admin", "/admin/items", itm(item_no="　N4　", brand="　B4　", name="　名前　"), desc="item add stripped")
S("staff", "/admin/items", itm(item_no="S1"), desc="staff cannot add item")
NEW_ITEM = "17"
ied = lambda **kw: dict({"brand": "NewB", "item_no": "N1", "name": "改名品番", "style": "長袖", "is_active": "on"}, **kw)
S("admin", f"/admin/items/{NEW_ITEM}", ied(), desc="item edit")
S("admin", f"/admin/items/{NEW_ITEM}", ied(brand="", item_no=""), desc="item edit clear both")
S("admin", f"/admin/items/{NEW_ITEM}", ied(brand="Printstar", item_no="085-CVT"), desc="item edit duplicate")
S("admin", f"/admin/items/{NEW_ITEM}", ied(style="あ" * 31), desc="item edit style 31")
S("admin", f"/admin/items/{NEW_ITEM}", {"brand": "NewB", "item_no": "N1", "name": "停止", "style": ""}, desc="item edit deactivate")
S("staff", "/receive", {"item_id": NEW_ITEM, "color": "黒", "size": "M", "qty": "1"}, desc="receive to just-stopped item")
S("admin", "/admin/items/999", ied(), desc="item edit unknown")
S("admin", "/admin/items/abc", ied(), desc="item edit non-numeric")
S("staff", f"/admin/items/{NEW_ITEM}", ied(), desc="staff cannot edit item")

# 管理: ユーザー
usr = lambda **kw: dict({"username": "newstaff", "password": "password99", "role": "staff"}, **kw)
S("admin", "/admin/users", usr(), desc="user add")
S("admin", "/admin/users", usr(), desc="user add duplicate")
S("admin", "/admin/users", usr(username="short", password="1234567"), desc="user add short password")
S("admin", "/admin/users", usr(username="jp", password="あいうえおかきく"), desc="user add 8-char japanese password")
S("admin", "/admin/users", usr(username="jp2", password="あいうえおかき"), desc="user add 7-char japanese password")
S("admin", "/admin/users", usr(username=""), desc="user add empty name")
S("admin", "/admin/users", usr(username="　"), desc="user add blank name")
S("admin", "/admin/users", usr(username="　spaced　", password="password99"), desc="user add spaced name")
S("admin", "/admin/users", usr(username="adm2", role="admin"), desc="user add admin")
S("admin", "/admin/users", usr(username="bogusrole", role="superuser"), desc="user add bogus role")
S("admin", "/admin/users", usr(username="norole", role=""), desc="user add empty role")
S("staff", "/admin/users", usr(username="x"), desc="staff cannot add user")
S("admin", "/admin/users/1/toggle", {}, desc="toggle self")
S("admin", "/admin/users/3/toggle", {}, desc="toggle other off")
S("admin", "/admin/users/3/toggle", {}, desc="toggle other on")
S("admin", "/admin/users/3/toggle", {}, desc="toggle other off again")
S("admin", "/admin/users/999/toggle", {}, desc="toggle unknown")
S("admin", "/admin/users/abc/toggle", {}, desc="toggle non-numeric")
S("admin", "/admin/users/4/password", {"password": "short"}, desc="reset short password")
S("admin", "/admin/users/4/password", {"password": "resetpass1"}, desc="reset password")
S("admin", "/admin/users/999/password", {"password": "resetpass1"}, desc="reset unknown")
S("staff", "/admin/users/4/password", {"password": "resetpass1"}, desc="staff cannot reset")

# パスワード変更 (staff)
S("staff", "/account/password", {"old": "wrong", "new": "newpass123", "confirm": "newpass123"}, desc="change: wrong old")
S("staff", "/account/password", {"old": "password123", "new": "short", "confirm": "short"}, desc="change: short")
S("staff", "/account/password", {"old": "password123", "new": "newpass123", "confirm": "different1"}, desc="change: mismatch")
S("staff", "/account/password", {"old": "password123", "new": "newpass123", "confirm": "newpass123"}, desc="change: ok")
S("anon", "/login", {"username": "staff", "password": "password123"}, desc="login with old password")
S("anon", "/login", {"username": "staff", "password": "newpass123"}, desc="login with new password")
S("anon", "/login", {"username": "newstaff", "password": "password99"}, desc="login added user (old pw after reset)")
S("anon", "/login", {"username": "newstaff", "password": "resetpass1"}, desc="login added user (reset pw, but disabled)")
S("anon", "/login", {"username": "jp", "password": "あいうえおかきく"}, desc="login japanese-password user")
S("anon", "/login", {"username": "spaced", "password": "password99"}, desc="login stripped username")

# CSRF
S("staff", "/receive", rec(), method="POST-NOCSRF", desc="POST without csrf token")


def run(make):
    sessions = {}
    results = []
    for who, method, path, data, desc in steps:
        if who not in sessions or (path == "/logout"):
            pass
        if who == "anon":
            s = Session(make())  # 毎回、新しいセッション (ログインの確認用)
        else:
            if who not in sessions:
                sessions[who] = new_session(make, who)
            s = sessions[who]
        page = "/login" if who == "anon" else "/account/password"  # トークンを取る画面 (未ログインでも開ける所)
        if method == "POST-NOCSRF":
            res = s.post(path, data, csrf=False)
        else:
            res = s.post(path, data, token_page=page)
        results.append((desc, res))
        if path == "/logout":
            sessions.pop(who, None)
    return results


flask_results = run(FlaskDriver)
go_results = run(GoDriver)
go_proc.terminate()
go_proc.wait(timeout=10)

# ---- 応答の比較 -----------------------------------------------------------------------------
bad = 0
for (d1, a), (d2, b) in zip(flask_results, go_results):
    assert d1 == d2
    if a != b:
        bad += 1
        print(f"\nRESPONSE DIFF [{d1}]\n  Flask: {json.dumps(a, ensure_ascii=False)}\n  Go   : {json.dumps(b, ensure_ascii=False)}")


# ---- 最終的な DB の比較 -----------------------------------------------------------------------
def dump(path):
    c = sqlite3.connect(path)
    q = {
        "user": 'SELECT id, username, role, is_active, substr(password_hash, 1, instr(password_hash, "$")) FROM "user" ORDER BY id',
        "category": "SELECT * FROM category ORDER BY id",
        "item": "SELECT id, category_id, brand, item_no, name, style, is_active FROM item ORDER BY id",
        "variant": "SELECT id, item_id, color, size, variant_name, quantity FROM variant ORDER BY id",
        "design": "SELECT id, name, note FROM design ORDER BY id",
        "printed_product": "SELECT id, design_id, variant_id, quantity FROM printed_product ORDER BY id",
        "stock_movement": "SELECT id, kind, variant_id, printed_product_id, delta, note, user_id FROM stock_movement ORDER BY id",
        "item_note": "SELECT id, item_id, target, body, is_resolved, user_id FROM item_note ORDER BY id",
    }
    out = {k: [list(r) for r in c.execute(v)] for k, v in q.items()}
    # batch_id は値そのものでなく、「同じ batch_id の履歴の組」が同じであること
    groups = {}
    for mid, bid in c.execute("SELECT id, batch_id FROM stock_movement ORDER BY id"):
        groups.setdefault(bid, []).append(mid)
    out["batches"] = sorted(groups.values())
    out["integrity"] = c.execute("PRAGMA integrity_check").fetchone()[0]
    out["fk_violations"] = len(c.execute("PRAGMA foreign_key_check").fetchall())
    out["user_version"] = c.execute("PRAGMA user_version").fetchone()[0]
    return out


a, b = dump(flask_db), dump(go_db)
for table in a:
    if a[table] != b[table]:
        bad += 1
        print(f"\nDB DIFF in {table}:")
        ra, rb = a[table], b[table]
        if isinstance(ra, list):
            for i in range(max(len(ra), len(rb))):
                x = ra[i] if i < len(ra) else None
                y = rb[i] if i < len(rb) else None
                if x != y:
                    print(f"  row {i}: Flask {x}\n         Go    {y}")
                    break
        else:
            print(f"  Flask {ra}  Go {rb}")
print(f"\n{len(steps)} requests, {bad} differences")
print("movements:", len(a["stock_movement"]), "| notes:", len(a["item_note"]), "| items:", len(a["item"]),
      "| users:", len(a["user"]), "| integrity:", a["integrity"], "| fk violations:", a["fk_violations"])
sys.exit(1 if bad else 0)
