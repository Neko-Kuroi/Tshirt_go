"""起動した Go 版サーバーに HTTP でアクセスして、画面を書き出す (tools/compare_html.py が読む)。

  python tools/fetch_pages.py <inventory のバイナリ> <出力先>

検証用 DB (internal/service/testdata/golden/inventory.db) のコピーで、サーバーを起動する。
Go のテストではなく本物のバイナリに HTTP で触るので、CLI・設定の読み込み・ミドルウェアも通る。
"""
import http.cookiejar
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

binary, out = sys.argv[1], pathlib.Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
root = pathlib.Path(__file__).resolve().parent.parent
golden = root / "internal/service/testdata/golden"
tmp = pathlib.Path(tempfile.mkdtemp())
shutil.copy(golden / "inventory.db", tmp / "inventory.db")
import atexit
import socket

with socket.socket() as _s:  # 空いているポートを選ぶ
    _s.bind(("127.0.0.1", 0))
    port = _s.getsockname()[1]
env = dict(os.environ, INVENTORY_DATABASE=str(tmp / "inventory.db"), INVENTORY_SECRET_KEY="x" * 32)
srv = subprocess.Popen([binary, "serve", "--addr", f"127.0.0.1:{port}"], env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
atexit.register(lambda: srv.poll() is None and srv.kill())
base = f"http://127.0.0.1:{port}"
for _ in range(50):
    try:
        urllib.request.urlopen(base + "/static/app.css", timeout=1)
        break
    except Exception:
        time.sleep(0.1)
else:
    srv.kill()
    sys.exit("server did not start: " + srv.stdout.read().decode(errors="replace"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect())


def fetch(op, path, data=None):
    try:
        with op.open(urllib.request.Request(base + path, data=data), timeout=20) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


def login(user):
    op = session()
    _, html = fetch(op, "/login")
    tok = re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)
    st, _ = fetch(op, "/login", urllib.parse.urlencode(
        {"username": user, "password": "password123", "csrf_token": tok}).encode())
    assert st == 302, f"login {user}: {st}"
    return op


paths = ["/", "/blank", "/blank?category=1", "/blank?category=2", "/blank?category=3", "/blank?category=4",
         "/blank?category=99", "/blank?q=Printstar", "/blank?category=1&q=United", "/blank?category=1&q=%25",
         "/blank?q=%E3%83%AF%E3%82%A4%E3%83%AB%E3%83%89", "/printed", "/printed?q=%E3%81%AD%E3%81%93", "/printed?q=zzz",
         "/blank/list",
         "/receive", "/receive?item_id=1", "/receive?item_id=3", "/receive?item_id=14", "/receive?item_id=999",
         "/receive?item_id=abc", "/convert", "/move", "/move?target=v:1",
         "/history", "/history?page=2", "/history?page=99", "/history?page=abc", "/history?kind=receive",
         "/history?kind=ship", "/history?kind=print_use", "/history?kind=bogus", "/history?kind=receive&page=2",
         "/notes", "/notes?all=1",
         "/admin/categories", "/admin/categories/1", "/admin/categories/3", "/admin/items", "/admin/items?category=1",
         "/admin/items?category=2", "/admin/items/1", "/admin/items/13", "/admin/items/16", "/admin/users",
         "/account/password"]
cases = json.loads((golden / "stocklist.json").read_text(encoding="utf-8"))
for cs in cases:
    paths.append("/blank/list?" + urllib.parse.urlencode([tuple(kv) for kv in cs["query"]]))

clients = {"admin": login("admin"), "staff": login("staff")}
index = {}
for i, p in enumerate(paths):
    for who in ("admin", "staff"):
        if who == "staff" and i % 4 != 0 and not p.startswith("/admin"):
            continue
        st, body = fetch(clients[who], p)
        name = f"{who}_{i}.html"
        (out / name).write_text(body, encoding="utf-8")
        index[f"{who} {p}"] = {"file": name, "status": st}
(out / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding="utf-8")
srv.terminate()
srv.wait(timeout=10)
print(f"{len(index)} pages written to {out}")
